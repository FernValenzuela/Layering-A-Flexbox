# Lesson plan
  
---

```
* {
  text-align: center;
}

#bgImg1 {
  background: url("https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Sea_Gulls_on_Beach.jpg/640px-Sea_Gulls_on_Beach.jpg") no-repeat center center;
  background-size: cover;
}
#bgImg2 {
    background: url("https://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Sea_gull%2C_Marseille.jpg/640px-Sea_gull%2C_Marseille.jpg") no-repeat center center;
  background-size: cover;
}

.flexy {
  display: flex;
}

.flexy > div {
  flex: 1;
  border: 4px solid blue;
  background-color: turquoise;
  height: 150px;
}

#mid-col {
  display: flex;
  flex: 3;
}

#mid-col div {
  background-color: lightblue;
  border: 2px solid red;
  flex: 1;
}
```