# Instructions  

---

Modify ONLY the 'style.css' file to make your page look like
the screenshot below:

![Screen shot](./assets/ScreenShot.png)

Use flexbox as well as background properties
in order to achieve this effect.